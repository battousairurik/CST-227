﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeper
{
    class Driver
    {
        static void Main(string[] args)
        {
            Game_Board game = new Game_Board();
            game.PopulateBoard();
            game.DisplayGameBoard();
        }
    }
    class Game_Board
    {
        private Cell [,] gameBoard;
        private int boardSize;

        public Game_Board()
        {
            DetermineBoardSize();
            gameBoard = new Cell[boardSize, boardSize];
        }
        //Method to determine board size
        private void DetermineBoardSize()
        {
            boardSize = 0;
            while (boardSize < 1 || boardSize > 50)
            {
                Console.WriteLine("Enter the board size you would like to generate. (Between 1 and 50)");
                boardSize = Convert.ToInt32(Console.ReadLine());
                if (boardSize < 1 || boardSize > 50)
                    Console.WriteLine("Invalid board size, please enter a number between 1 and 50");
            }
            Console.WriteLine("Thank you, your board will be displayed shortly.");
        }
        //Method to create each Cell and fill the gameBoard
        public void PopulateBoard ()
        {
            for (int i = 0; i < gameBoard.GetLength(0); i++)
            {
                for (int j = 0; j < gameBoard.GetLength(1); j++)
                {
                    Cell gameCell = new Cell(i, j);
                    gameCell.IsLive = DetermineIsLive();
                    if (gameCell.IsLive == true)
                        gameCell.Neighbors = 9;
                    gameBoard[i, j] = gameCell;
                }
            }
            DetermineLiveNeighbors();
        }
        //Private field and method to determine if the Cell is live
        private Random random = new Random();
        public Boolean DetermineIsLive()
        {
            int x = random.Next(101);
            if ( x > 80)
                return true;
            else
                return false;
        }
        //Method to determine number of live neighbors
        private void DetermineLiveNeighbors()
        {
            for (int i = 0; i < gameBoard.GetLength(0); i++)
            {
                for (int j = 0; j < gameBoard.GetLength(1); j++)
                {
                    int x = 0;

                    x += CheckNeighbors(i-1, j-1);
                    x += CheckNeighbors(i-1, j);
                    x += CheckNeighbors(i-1, j+1);
                    x += CheckNeighbors(i, j-1);
                    x += CheckNeighbors(i, j+1);
                    x += CheckNeighbors(i+1, j-1);
                    x += CheckNeighbors(i+1, j);
                    x += CheckNeighbors(i+1, j+1);

                    gameBoard[i, j].Neighbors = x;
                }
            }
        }
        private int CheckNeighbors (int x, int y)
        {
            if (x > -1  && y > -1 )
            {
                if (x < boardSize && y < boardSize)
                {
                    if (gameBoard[x, y].IsLive == true)
                        return 1;
                }
            }
            return 0;
        }
        //Method to print maze to console
        public void DisplayGameBoard()
        {
            for (int i = 0; i < gameBoard.GetLength(0); i++)
            {
                for (int j = 0; j < gameBoard.GetLength(1); j++)
                {
                    if (gameBoard[i,j].IsLive)
                        Console.Write("* ");
                    else
                        Console.Write("{0} ", gameBoard[i, j].Neighbors);
                }
                Console.Write("\n");
            }
            Console.ReadLine();
        }
    }
    class Cell
    {
        private int row, column, neighbors;
        private Boolean isVisited, isLive;

        public Cell() { }

        public Cell (int row, int column)
        {
            this.row = row;
            this.column = column;
            neighbors = 0;
            isVisited = false;
            isLive = false;
        }
        //Default accessor and mutator methods
        public int Row
        {
            set { row = value; }
            get { return row; }
        }
        public int Column
        {
            set => column = value; 
            get => column; 
        }
        
        public int Neighbors
        {
            set => neighbors = value;
            get => neighbors;
        }
        public Boolean IsVisited
        {
            set => isVisited = value;
            get => isVisited;
        }
        public Boolean IsLive
        {
            set => isLive = value;
            get => isLive;
        }
    }
}
