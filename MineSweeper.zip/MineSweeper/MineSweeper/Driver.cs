﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MineSweeper.Controllers;

namespace MineSweeper
{
    class Driver
    {
        static void Main(string[] args)
        {
            int gameBoardSize = -25;
            int minimumSize = 1;
            int maxSize = 50;
            try
            {
                GameBoard game = new GameBoard(gameBoardSize, minimumSize, maxSize);
                if (!game.BoardState)
                {
                    Console.WriteLine("Invalid board state, please change the board size.");
                    return;
                }
                game.PopulateBoard();
                game.DisplayGameBoard();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }
    }
}
    
