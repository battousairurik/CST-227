﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MineSweeper.Controllers;

namespace MineSweeper
{
    class Driver
    {
        static void Main(string[] args)
        {
            Game_Board game = new Game_Board();
            game.PopulateBoard();
            game.DisplayGameBoard();
        }
    }
}
    
